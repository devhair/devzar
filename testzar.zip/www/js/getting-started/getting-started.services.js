angular.module('your_app_name.getting-started.services', [])

.service('TestService', function ($http, $q){
  this.testMethod = function(){

  };
})

;
