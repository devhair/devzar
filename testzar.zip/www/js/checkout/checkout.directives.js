angular.module('your_app_name.checkout.directives', [])


;
