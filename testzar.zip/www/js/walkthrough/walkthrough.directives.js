angular.module('your_app_name.walkthrough.directives', [])

.directive('testDirective', function($timeout) {
	return {
		restrict: 'A',
		scope: {
		},
		controller: function($scope) {

		},
		link: function(scope, element, attr, ctrl) {

		}
	};
})

;
