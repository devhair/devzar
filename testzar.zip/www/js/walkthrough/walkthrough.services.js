angular.module('your_app_name.walkthrough.services', [])

.service('TestService', function ($http, $q){
  this.testMethod = function(){

  };
})

;
