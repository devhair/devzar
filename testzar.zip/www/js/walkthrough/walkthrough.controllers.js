angular.module('your_app_name.walkthrough.controllers', [])

.controller('TestCtrl', function($scope) {

})


;
