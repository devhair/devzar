angular.module('your_app_name.content.services', [])

.service('TestService', function ($http, $q){
  this.testMethod = function(){

  };
})

;
