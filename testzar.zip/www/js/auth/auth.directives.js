angular.module('your_app_name.auth.directives', [])

.directive('testDirective', function($timeout) {
	return {
		restrict: 'A',
		scope: {
		},
		controller: function($scope) {

		},
		link: function(scope, element, attr, ctrl) {
			
		}
	};
})

;
