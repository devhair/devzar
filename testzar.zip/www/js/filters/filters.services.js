angular.module('your_app_name.filters.services', [])

.service('TestService', function ($http, $q){
  this.testMethod = function(){

  };
})

;
