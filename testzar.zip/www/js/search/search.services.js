angular.module('your_app_name.search.services', [])

.service('TestService', function ($http, $q){
  this.testMethod = function(){

  };
})

;
