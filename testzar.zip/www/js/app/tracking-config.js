angular.module("analytics.mixpanel")

.constant("APP_NAME", "bazaar")

.constant("APP_VERSION", "1.0.2")

.constant("MIXPANEL_API_KEY", "096f7caeab884e0897e9614427866280")

.constant("MIXPANEL_OPENED_USING", "apk")

.constant("MIXPANEL_DOWNLOAD_REFERRAL", "ionic-market")

;