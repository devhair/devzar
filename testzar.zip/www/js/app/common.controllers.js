angular.module('your_app_name.common.controllers', [])

.controller('AppCtrl', function($scope, $ionicHistory, logged_user) {

})

;
